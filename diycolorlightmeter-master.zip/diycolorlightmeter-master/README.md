# diycolorlightmeter (Re-wrote!)
Improved computational complexity and memory usage
Look into My_Photometer_v3.3 folder
