# ƒLUX
Arduino Light Meter

This is my Arduino light meter project. The goal was to build a portable, low-power light meter for photography and cinematography.

I used an Adafruit TSL2591 High Dynamic Range Light Sensor (https://www.adafruit.com/product/1980), an Arduino Pro Mini, a 128x64 I2c OLED Display, a push-button a rotary encoder, and three AAA batteries.

Here's a video: https://www.youtube.com/watch?v=WcZG9v7m2E0
